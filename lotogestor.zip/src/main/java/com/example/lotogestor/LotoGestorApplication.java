package com.example.lotogestor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LotoGestorApplication {

	public static void main(String[] args) {
		SpringApplication.run(LotoGestorApplication.class, args);
	}

}
