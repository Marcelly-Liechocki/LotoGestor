package com.example.lotogestor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LotoGestorApplicationTests {

	@Test
	void contextLoads() {
	}

}
